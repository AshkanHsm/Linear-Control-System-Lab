clc
close all
clear all
s=tf('s');
J=0.001;
b=0.01;
R=0.1;
L=0.05;
Ke=0.1;
Kt=0.01;
H=Kt/((R+L*s)*(b+J*s)+Kt*Ke)
bode(H,0.01:0.001:1000)
grid